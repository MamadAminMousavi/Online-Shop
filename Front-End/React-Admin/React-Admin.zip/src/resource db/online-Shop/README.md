# online-Shop
online shop project use flask and react admin for back-end and html,css,js for front-end and database sqllite.
react admin full,flask 70%, front 20%
